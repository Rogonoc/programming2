/* ---- DON'T TOUCH ---- */
#include "rclcpp/rclcpp.hpp"
/* --------------------- */

// Standard libraries
#include <functional>
#include <memory>
#include <iostream>
#include <numeric>
#include <stdio.h>
#include <chrono>
#include <string>
#include <queue>
#include <vector>

// Topic message types
#include "dynamic_system_vectors/msg/velocity.hpp" // Message type of input and output topic


/* --------------- DONT TOUCH --------------- */
using std::placeholders::_1;
using namespace std;
using namespace std::chrono_literals;
/* ------------------------------------------ */


/* --------------- Global variables --------------- */
std::queue<std::vector<double>> buffer;
/* ------------------------------------------------ */


/* --------------- USER INPUT --------------- */
// Node name
string node_name = "buffer_nrt_srt"; 

// Input topic name 
string input_topic_name = "velocityVector";

// Output topic name 
string output_topic_name = "velocityVector_buffer";

/* ------------------------------------------ */



// Create class for node
class BufferNRTtoSRT : public rclcpp::Node
{
public:
  BufferNRTtoSRT() : Node(node_name)
  {
    /* --------------------- DONT TOUCH --------------------- */
    auto default_qos = rclcpp::QoS(rclcpp::SystemDefaultsQoS());
    /* ------------------------------------------------------ */

    /* --------------------- PARAMETERS --------------------- */
    this->declare_parameter<double>("stepTime", 0.01);    // (parameter1)  replace <bool> with desired type

    // Store stepTime in variable (parameter1)
    double stepTime; // Replace with desired type
    this->get_parameter("stepTime", stepTime);

    // Publish period 
    double period_in_seconds = stepTime;
    auto publish_period = std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(period_in_seconds));
    /* ------------------------------------------------------ */

    // Subscriber 
    subscription_ = this->create_subscription<dynamic_system_vectors::msg::Velocity>(
      input_topic_name,
      default_qos,
      std::bind(&BufferNRTtoSRT::subscriber_callback, this, _1));

    // Publisher 
    publisher_ = this->create_publisher<dynamic_system_vectors::msg::Velocity>(
      output_topic_name, 
      default_qos);
    timer_ = this->create_wall_timer(
      publish_period, 
      std::bind(&BufferNRTtoSRT::publisher_callback, 
      this));
  }

private:

  // FUNCTION FOR SUBSCRIBER 
  void subscriber_callback(const dynamic_system_vectors::msg::Velocity::SharedPtr msg) const
  {
    /* ----------------------------- PARAMETERS ---------------------------- */
    std::vector<double> velocityVector{};
    /* --------------------------------------------------------------------- */


    /* --------------------- DATA PROCESSING PART HERE --------------------- */
    // Get current velocity vector
    velocityVector = { msg->xvelocity, msg->yvelocity };

    // Put velocity vector into buffer
	  if (buffer.size() < 10) {
      buffer.push(velocityVector);
    }
    /* --------------------------------------------------------------------- */

    // Print data to terminal
    //RCLCPP_INFO(this->get_logger(),
    //"I see:  %f",              // Type % to print 
    //msg->data[0]);             // To-be-printed variables
  }


  // FUNCTION FOR PUBLISHER 
  void publisher_callback()
  {
    /* ----------------------------- PARAMETERS --------------------------- */
    std::vector<double> velocityVector{};
    /* -------------------------------------------------------------------- */


    /* --------------------- DATA PROCESSING PART HERE -------------------- */

    // (BEGIN) Message type
    auto msg = dynamic_system_vectors::msg::Velocity();
 
    // [END] Attach data to message
    if (buffer.size() != 0) {
      // Retrieve last value
      velocityVector = buffer.front();
      
      // Attach to msg
      msg.xvelocity = velocityVector[0];
      msg.yvelocity = velocityVector[1];

      // Remove this value from buffer
      buffer.pop();
    } else {
      // Zero output
      msg.xvelocity = 0;
      msg.yvelocity = 0;
    }

    /* -------------------------------------------------------------------- */

    // Print data to terminal
    //RCLCPP_INFO(this->get_logger(), 
    //"Publishing: '%f'",      // Type % to print 
    //message.data);           // To-be-printed variables

    // Publish attached information to topic
    publisher_->publish(msg);
  }

  // Subscription side 
  rclcpp::Subscription<dynamic_system_vectors::msg::Velocity>::SharedPtr subscription_; 

  // Publisher side 
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<dynamic_system_vectors::msg::Velocity>::SharedPtr publisher_;
  size_t count_;
};


// Main function to be executed
int main(int argc, char * argv[])
{
  // Initialization of node
  rclcpp::init(argc, argv);

  // Start the node
  rclcpp::spin(std::make_shared<BufferNRTtoSRT>());

  // Allow Ctrl + C to be used to shutdown the node
  rclcpp::shutdown();

  // Neglect
  return 0;
}
