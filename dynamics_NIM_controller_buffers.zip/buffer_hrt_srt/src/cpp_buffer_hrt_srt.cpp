/* ---- DON'T TOUCH ---- */
#include "rclcpp/rclcpp.hpp"
/* --------------------- */

// Standard libraries
#include <functional>
#include <memory>
#include <iostream>
#include <numeric>
#include <stdio.h>
#include <chrono>
#include <string>
#include <queue>
#include <vector>

// Topic message types
#include "dynamic_system_vectors/msg/state.hpp" // Message type of input and output topic


/* --------------- DONT TOUCH --------------- */
using std::placeholders::_1;
using namespace std;
using namespace std::chrono_literals;
/* ------------------------------------------ */


/* --------------- Global variables --------------- */
std::queue<std::vector<double>> buffer;
/* ------------------------------------------------ */


/* --------------- USER INPUT --------------- */
// Node name
string node_name = "buffer_hrt_srt"; 

// Input topic name 
string input_topic_name = "stateVector";

// Output topic name 
string output_topic_name = "stateVector_buffer";

/* ------------------------------------------ */



// Create class for node
class BufferHRTtoSRT : public rclcpp::Node
{
public:
  BufferHRTtoSRT() : Node(node_name)
  {
    /* --------------------- DONT TOUCH --------------------- */
    auto default_qos = rclcpp::QoS(rclcpp::SystemDefaultsQoS());
    /* ------------------------------------------------------ */

    /* --------------------- PARAMETERS --------------------- */
    this->declare_parameter<double>("stepTime", 0.01);    // (parameter1)  replace <bool> with desired type

    // Store stepTime in variable (parameter1)
    double stepTime; // Replace with desired type
    this->get_parameter("stepTime", stepTime);

    // Publish period 
    double period_in_seconds = stepTime;
    auto publish_period = std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(period_in_seconds));
    /* ------------------------------------------------------ */

    // Subscriber 
    subscription_ = this->create_subscription<dynamic_system_vectors::msg::State>(
      input_topic_name,
      default_qos,
      std::bind(&BufferHRTtoSRT::subscriber_callback, this, _1));

    // Publisher 
    publisher_ = this->create_publisher<dynamic_system_vectors::msg::State>(
      output_topic_name, 
      default_qos);
    timer_ = this->create_wall_timer(
      publish_period, 
      std::bind(&BufferHRTtoSRT::publisher_callback, 
      this));
  }

private:

  // FUNCTION FOR SUBSCRIBER 
  void subscriber_callback(const dynamic_system_vectors::msg::State::SharedPtr msg) const
  {
    /* ----------------------------- PARAMETERS ---------------------------- */
    std::vector<double> stateVector{};
    /* --------------------------------------------------------------------- */


    /* --------------------- DATA PROCESSING PART HERE --------------------- */
    // Get current state vector
    stateVector = { msg->xdrone, msg->xdotdrone, msg->thetadrone, msg->ydrone, msg->ydotdrone,
                    msg->xcargo, msg->xdotcargo, msg->ycargo, msg->ydotcargo };

    // Put state vector into buffer
	  if (buffer.size() < 10) {
      buffer.push(stateVector);
    }
    /* --------------------------------------------------------------------- */

    // Print data to terminal
    //RCLCPP_INFO(this->get_logger(),
    //"I see:  %f",              // Type % to print 
    //msg->data[0]);             // To-be-printed variables
  }


  // FUNCTION FOR PUBLISHER 
  void publisher_callback()
  {
    /* ----------------------------- PARAMETERS --------------------------- */
    std::vector<double> stateVector{};
    /* -------------------------------------------------------------------- */


    /* --------------------- DATA PROCESSING PART HERE -------------------- */

    // (BEGIN) Message type
    auto msg = dynamic_system_vectors::msg::State();
 
    // [END] Attach data to message
    if (buffer.size() != 0) {
      // Retrieve last value
      stateVector = buffer.front();
      
      // Attach to msg
      msg.xdrone = stateVector[0];
      msg.xdotdrone = stateVector[1];
      msg.thetadrone = stateVector[2];
      msg.ydrone = stateVector[3];
      msg.ydotdrone = stateVector[4];
      msg.xcargo = stateVector[5];
      msg.xdotcargo = stateVector[6];
      msg.ycargo = stateVector[7];
      msg.ydotcargo = stateVector[8];

      // Remove this value from buffer
      buffer.pop();
    } 

    /* -------------------------------------------------------------------- */

    // Print data to terminal
    //RCLCPP_INFO(this->get_logger(), 
    //"Publishing: '%f'",      // Type % to print 
    //message.data);           // To-be-printed variables

    // Publish attached information to topic
    publisher_->publish(msg);
  }

  // Subscription side 
  rclcpp::Subscription<dynamic_system_vectors::msg::State>::SharedPtr subscription_; 

  // Publisher side 
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<dynamic_system_vectors::msg::State>::SharedPtr publisher_;
  size_t count_;
};


// Main function to be executed
int main(int argc, char * argv[])
{
  // Initialization of node
  rclcpp::init(argc, argv);

  // Start the node
  rclcpp::spin(std::make_shared<BufferHRTtoSRT>());

  // Allow Ctrl + C to be used to shutdown the node
  rclcpp::shutdown();

  // Neglect
  return 0;
}
