/* ---- DON'T TOUCH ---- */
#include "rclcpp/rclcpp.hpp"
/* --------------------- */

// Standard libraries
#include <functional>
#include <memory>
#include <iostream>
#include <numeric>
#include <stdio.h>
#include <chrono>
#include <string>

// User-created library
#include "DroneControllerControlVector.h"
#include "DroneDynamics.h"
#include "CargoDynamics.h"

// Topic message types
#include "dynamic_system_vectors/msg/velocity.hpp"  // Message type of input topic (i)
#include "dynamic_system_vectors/msg/state.hpp"     // Message type of input topic (ii)
#include "dynamic_system_vectors/msg/control.hpp"   // Message type of output topic


/* --------------- DONT TOUCH --------------- */
using std::placeholders::_1;
using namespace std;
using namespace std::chrono_literals;
/* ------------------------------------------ */


/* --------------- Global variables --------------- */
DroneControllerControlVector controller;
DroneDynamics drone;
CargoDynamics cargo;

// Set time constants
double timeConstantX = 0.2;		// in [s]
double timeConstantY = 0.2;		// in [s]
double timeConstantTheta = 0.1;	// in [s]

// Set controller damping
double oscillationDampingConstant = 50; // in [N / m]

// Set gravitational force
double gravitationalConstant = 9.81;	// in [m / s^2]

// Set drone parameters
double massDrone = 3;		// in [kg]

// Set cargo parameters
double massCargo = 2;	// in [kg]

/* ------------------------------------------------ */


/* --------------- USER INPUT --------------- */
// Node name
string node_name = "controller"; 

// Input topic name (1)
string input_topic_name1 = "velocityVector_buffer";

// Input topic name (2)
string input_topic_name2 = "stateVector_buffer";

// Output topic name 
string output_topic_name = "controlVector";

/* ------------------------------------------ */



// Create class for node
class FeedbackController : public rclcpp::Node
{
public:
  FeedbackController() : Node(node_name)
  {
    /* --------------------- DONT TOUCH --------------------- */
    auto default_qos = rclcpp::QoS(rclcpp::SystemDefaultsQoS());
    /* ------------------------------------------------------ */

    /* --------------------- PARAMETERS --------------------- */
    this->declare_parameter<double>("timeStep", 0.01);    // (parameter1)  replace <bool> with desired type
    this->declare_parameter<bool>("dynamicsType", false); // (parameter2)  replace <bool> with desired type

    // Set time constants
    controller.setTimeConstants(timeConstantX, timeConstantY, timeConstantTheta);

    // Store integrationType in variable (parameter1)
    bool timeStep; // Replace with desired type
    this->get_parameter("timeStep", timeStep);

    // Publish period 
    double period_in_seconds = timeStep;
    auto publish_period = std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(period_in_seconds));
    /* ------------------------------------------------------ */

    // Subscriber (1)
    subscription_1 = this->create_subscription<dynamic_system_vectors::msg::Velocity>(
      input_topic_name1,
      default_qos,
      std::bind(&FeedbackController::subscriber_callback_1, this, _1));

    // Subscriber (2)
    subscription_2 = this->create_subscription<dynamic_system_vectors::msg::State>(
      input_topic_name2,
      default_qos,
      std::bind(&FeedbackController::subscriber_callback_2, this, _1));

    // Publisher 
    publisher_ = this->create_publisher<dynamic_system_vectors::msg::Control>(
      output_topic_name, 
      default_qos);
    timer_ = this->create_wall_timer(
      publish_period, 
      std::bind(&FeedbackController::publisher_callback, 
      this));
  }

private:

  // FUNCTION FOR SUBSCRIBER (i)
  void subscriber_callback_1(const dynamic_system_vectors::msg::Velocity::SharedPtr msg) const
  {
    /* ----------------------------- PARAMETERS ---------------------------- */
    std::vector<double> velocityVector{};
    /* --------------------------------------------------------------------- */


    /* --------------------- DATA PROCESSING PART HERE --------------------- */
    // Retrieve required velocity vector from subscription
    velocityVector = { msg->xvelocity, msg->yvelocity };

    // Update and save velocity vector of object
	  controller.setVelocityVector(velocityVector);
    /* --------------------------------------------------------------------- */

    // Print data to terminal
    //RCLCPP_INFO(this->get_logger(),
    //"I see:  %f",              // Type % to print 
    //msg->data[0]);             // To-be-printed variables
  }

  // FUNCTION FOR SUBSCRIBER (ii)
  void subscriber_callback_2(const dynamic_system_vectors::msg::State::SharedPtr msg) const
  {
    /* ----------------------------- PARAMETERS ---------------------------- */
    std::vector<double> stateVector{};
    /* --------------------------------------------------------------------- */


    /* --------------------- DATA PROCESSING PART HERE --------------------- */
    // Retrieve required states from state vector; ssave these
    drone.setXDrone(msg->xdrone);
    drone.setXDotDrone(msg->xdotdrone);
    drone.setThetaDrone(msg->thetadrone);
    drone.setYDrone(msg->ydrone);
    drone.setYDotDrone(msg->ydotdrone);
    cargo.setXCargo(msg->xcargo);
    cargo.setYCargo(msg->ycargo);

    /* --------------------------------------------------------------------- */

    // Print data to terminal
    //RCLCPP_INFO(this->get_logger(),
    //"I see:  %f",              // Type % to print 
    //msg->data[0]);             // To-be-printed variables
  }

  // FUNCTION FOR PUBLISHER 
  void publisher_callback()
  {
    /* ----------------------------- PARAMETERS --------------------------- */
    std::vector<double> currentControlVector{};

    // Store dynamicsType in variable (parameter2)
    bool dynamicsType; // Replace with desired type
    this->get_parameter("dynamicsType", dynamicsType);

    double xDrone{}, xDotDrone{}, yDrone{}, yDotDrone{}, thetaDrone{};
    double xCargo{}, yCargo{};
    /* -------------------------------------------------------------------- */


    /* --------------------- DATA PROCESSING PART HERE -------------------- */

    // (BEGIN) Message type
    auto msg = dynamic_system_vectors::msg::Control();

    // Retrieve drone and cargo state
    xDrone = drone.getXDrone();
    xDotDrone = drone.getXDotDrone();
    yDrone = drone.getYDrone();
    yDotDrone = drone.getYDotDrone();
    thetaDrone = drone.getThetaDrone();
    xCargo = cargo.getXCargo();
    yCargo = cargo.getYCargo();

    // Get current control vector
	  currentControlVector = controller.calculateReferenceControlVector(dynamicsType, gravitationalConstant,
																		                                  massDrone, xDrone, xDotDrone, yDrone, yDotDrone, thetaDrone,
																		                                  massCargo, xCargo, yCargo);
 
    // [END] Attach data to message
    msg.tau = currentControlVector[0];
    msg.omega = currentControlVector[1];

    /* -------------------------------------------------------------------- */

    // Print data to terminal
    //RCLCPP_INFO(this->get_logger(), 
    //"Publishing: '%f'",      // Type % to print 
    //message.data);           // To-be-printed variables

    // Publish attached information to topic
    publisher_->publish(msg);
  }

  // Subscription side 
  rclcpp::Subscription<dynamic_system_vectors::msg::Velocity>::SharedPtr subscription_1; 
  rclcpp::Subscription<dynamic_system_vectors::msg::State>::SharedPtr subscription_2; 

  // Publisher side 
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<dynamic_system_vectors::msg::Control>::SharedPtr publisher_;
  size_t count_;
};


// Main function to be executed
int main(int argc, char * argv[])
{
  // Initialization of node
  rclcpp::init(argc, argv);

  // Start the node
  rclcpp::spin(std::make_shared<FeedbackController>());

  // Allow Ctrl + C to be used to shutdown the node
  rclcpp::shutdown();

  // Neglect
  return 0;
}
