/* ---- DON'T TOUCH ---- */
#include "rclcpp/rclcpp.hpp"
/* --------------------- */

// Standard libraries
#include <functional>
#include <memory>
#include <iostream>
#include <numeric>
#include <stdio.h>
#include <chrono>
#include <string>

// User-created library
#include "DroneRopeCargoSimulator.h"

// Topic message types
#include "dynamic_system_vectors/msg/control.hpp" // Message type of input topic
#include "dynamic_system_vectors/msg/state.hpp"   // Message type of output topic


/* --------------- DONT TOUCH --------------- */
using std::placeholders::_1;
using namespace std;
using namespace std::chrono_literals;
/* ------------------------------------------ */


/* --------------- Global variables --------------- */
DroneRopeCargoSimulator simulator;
/* ------------------------------------------------ */


/* --------------- USER INPUT --------------- */
// Node name
string node_name = "dynamics_simulator"; 

// Input topic name 
string input_topic_name = "controlVector_buffer";

// Output topic name 
string output_topic_name = "stateVector";

/* ------------------------------------------ */



// Create class for node
class DynamicsSimulator : public rclcpp::Node
{
public:
  DynamicsSimulator() : Node(node_name)
  {
    /* --------------------- DONT TOUCH --------------------- */
    auto default_qos = rclcpp::QoS(rclcpp::SystemDefaultsQoS());
    /* ------------------------------------------------------ */

    /* --------------------- PARAMETERS --------------------- */
    this->declare_parameter<bool>("dynamicsType", false);    // (parameter1)  replace <bool> with desired type
    this->declare_parameter<bool>("integrationType", false); // (parameter2)  replace <bool> with desired type

    // Store dynamicsType in variable (parameter1)
    bool dynamicsType; // Replace with desired type
    this->get_parameter("dynamicsType", dynamicsType);

    // Store integrationType in variable (parameter2)
    bool integrationType; // Replace with desired type
    this->get_parameter("integrationType", integrationType);

    // Initialize implementation of simulator
    simulator.setImplementation(dynamicsType, integrationType);

    // Publish period 
    double period_in_seconds = simulator.getTimeStep();
    auto publish_period = std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(period_in_seconds));
    /* ------------------------------------------------------ */

    // Subscriber 
    subscription_ = this->create_subscription<dynamic_system_vectors::msg::Control>(
      input_topic_name,
      default_qos,
      std::bind(&DynamicsSimulator::subscriber_callback, this, _1));

    // Publisher 
    publisher_ = this->create_publisher<dynamic_system_vectors::msg::State>(
      output_topic_name, 
      default_qos);
    timer_ = this->create_wall_timer(
      publish_period, 
      std::bind(&DynamicsSimulator::publisher_callback, 
      this));
  }

private:

  // FUNCTION FOR SUBSCRIBER 
  void subscriber_callback(const dynamic_system_vectors::msg::Control::SharedPtr msg) const
  {
    /* ----------------------------- PARAMETERS ---------------------------- */
    std::vector<double> controlVector{};
    /* --------------------------------------------------------------------- */


    /* --------------------- DATA PROCESSING PART HERE --------------------- */
    // Retrieve required control vector from subscription
    controlVector = { msg->tau, msg->omega };

    // Step with simulator object; state vector of object is updated
    simulator.simulationStep(controlVector);
    /* --------------------------------------------------------------------- */

    // Print data to terminal
    //RCLCPP_INFO(this->get_logger(),
    //"I see:  %f",              // Type % to print 
    //msg->data[0]);             // To-be-printed variables
  }


  // FUNCTION FOR PUBLISHER 
  void publisher_callback()
  {
    /* ----------------------------- PARAMETERS --------------------------- */
    std::vector<double> currentOutputVector{};
    /* -------------------------------------------------------------------- */


    /* --------------------- DATA PROCESSING PART HERE -------------------- */

    // (BEGIN) Message type
    auto msg = dynamic_system_vectors::msg::State();

    // Get current output vector
    currentOutputVector = simulator.getStateVector();
 
    // [END] Attach data to message
    msg.xdrone = currentOutputVector[0];
    msg.xdotdrone = currentOutputVector[1];
    msg.thetadrone = currentOutputVector[2];
    msg.ydrone = currentOutputVector[3];
    msg.ydotdrone = currentOutputVector[4];
    msg.xcargo = currentOutputVector[5];
    msg.xdotcargo = currentOutputVector[6];
    msg.ycargo = currentOutputVector[7];
    msg.ydotcargo = currentOutputVector[8];

    /* -------------------------------------------------------------------- */

    // Print data to terminal
    //RCLCPP_INFO(this->get_logger(), 
    //"Publishing: '%f'",      // Type % to print 
    //message.data);           // To-be-printed variables

    // Publish attached information to topic
    publisher_->publish(msg);
  }

  // Subscription side 
  rclcpp::Subscription<dynamic_system_vectors::msg::Control>::SharedPtr subscription_; 

  // Publisher side 
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<dynamic_system_vectors::msg::State>::SharedPtr publisher_;
  size_t count_;
};


// Main function to be executed
int main(int argc, char * argv[])
{
  /* ------------------------ SIMULATOR PARAMETERS ------------------------ */

  // Initialize drone parameters
	double massDrone = 3;			      // in [kg]
	double dragConstantDrone = 0.1;	// in [N s^2 / m^2]
	simulator.setConstantDroneParameters(massDrone, dragConstantDrone);

	// Initialize rope parameters
	double ropeInitialLength = 1.5;	// in [m]
	double ropeDamping = 50;		    // in [N s / m]
	double ropeStiffness = 40000;	  // in [N / m]
	simulator.setConstantRopeParameters(ropeInitialLength, ropeDamping, ropeStiffness);

	// Initialize cargo parameters
	double cargoMass = 2;			      // in [kg]
	double dragConstantCargo = 0.1;	// in [N s^2 / m^2]
	simulator.setConstantCargoParameters(cargoMass, dragConstantCargo);

  /* ---------------------------------------------------------------------- */

  // Initialization of node
  rclcpp::init(argc, argv);

  // Start the node
  rclcpp::spin(std::make_shared<DynamicsSimulator>());

  // Allow Ctrl + C to be used to shutdown the node
  rclcpp::shutdown();

  // Neglect
  return 0;
}
